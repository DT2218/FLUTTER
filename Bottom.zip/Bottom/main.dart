import 'package:bottom/Car.dart';
import 'package:bottom/DetailView.dart';
import 'package:bottom/GlobalList.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Dhruvil(),
  ));
}

class Dhruvil extends StatefulWidget {
  const Dhruvil({super.key});

  @override
  State<Dhruvil> createState() => _DhruvilState();
}

class _DhruvilState extends State<Dhruvil> {
  int selectedindex = 0;
  List<Widget> lst = [Add(), Display(), Search()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Center(child: Text("Bottom Navigation")),
      ),
      bottomNavigationBar: BottomNavigationBar(
          onTap: (value) {
            selectedindex = value;
            setState(() {});
          },
          currentIndex: selectedindex,
          items: [
            BottomNavigationBarItem(label: "Add", icon: Icon(Icons.add)),
            BottomNavigationBarItem(
                label: "Display", icon: Icon(Icons.display_settings)),
            BottomNavigationBarItem(label: "Search", icon: Icon(Icons.search))
          ]),
      body: lst[selectedindex],
    );
  }
}

class Add extends StatefulWidget {
  const Add({super.key});

  @override
  State<Add> createState() => _AddState();
}

class _AddState extends State<Add> {
  TextEditingController txtName = new TextEditingController();
  TextEditingController txtPrice = new TextEditingController();
  TextEditingController txtColor = new TextEditingController();
  String View = "Total Data : ";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: Center(child: Text("Add")),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtName,
              decoration: InputDecoration(
                  label: Text("Enter Your Name"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtPrice,
              decoration: InputDecoration(
                  label: Text("Enter Your Price"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtColor,
              decoration: InputDecoration(
                  label: Text("Enter Your Color"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ElevatedButton(
              onPressed: () {
                Car obj = new Car();
                obj.Name = txtName.text;
                obj.Price = double.parse(txtPrice.text);
                obj.Color = txtColor.text;
                GlobalList.lst.add(obj);
                View = "Total Data : " + GlobalList.lst.length.toString();
                setState(() {});
              },
              child: Text("Add")),
          SizedBox(
            height: 10,
          ),
          Text(
            View,
            style: TextStyle(color: Colors.red, fontSize: 30),
          )
        ],
      ),
    );
  }
}

class Display extends StatefulWidget {
  const Display({super.key});

  @override
  State<Display> createState() => _DisplayState();
}

class _DisplayState extends State<Display> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow,
        title: Center(child: Text("Display")),
      ),
      body: ListView.builder(
        itemCount: GlobalList.lst.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              tileColor: Colors.orange,
              hoverColor: Colors.blue,
              title: Text(GlobalList.lst[index].Name),
              subtitle: Text(GlobalList.lst[index].Price.toString()),
              leading: Icon(Icons.display_settings),
              onTap: () {
                GlobalList.selectedindex = index;
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return DetailView();
                  },
                )).then(
                  (value) {
                    setState(() {});
                  },
                );
              },
            ),
          );
        },
      ),
    );
    ;
  }
}

class Search extends StatefulWidget {
  const Search({super.key});

  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: Center(child: Text("Search")),
      ),
    );
  }
}
