import 'package:bottom/GlobalList.dart';
import 'package:flutter/material.dart';

class Edit extends StatefulWidget {
  const Edit({super.key});

  @override
  State<Edit> createState() => _EditState();
}

class _EditState extends State<Edit> {
  TextEditingController txtName = new TextEditingController();
  TextEditingController txtPrice = new TextEditingController();
  TextEditingController txtColor = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    txtName.text = GlobalList.lst[GlobalList.selectedindex].Name;
    txtPrice.text = GlobalList.lst[GlobalList.selectedindex].Price.toString();
    txtColor.text = GlobalList.lst[GlobalList.selectedindex].Color;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lime,
        title: Center(child: Text("Edit Data")),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtName,
              decoration: InputDecoration(
                  label: Text("Enter Your Name"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtPrice,
              decoration: InputDecoration(
                  label: Text("Enter Your Price"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtColor,
              decoration: InputDecoration(
                  label: Text("Enter Your Color"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ElevatedButton(
              onPressed: () {
                GlobalList.lst[GlobalList.selectedindex].Name = txtName.text;
                GlobalList.lst[GlobalList.selectedindex].Price =
                    double.parse(txtPrice.text);
                GlobalList.lst[GlobalList.selectedindex].Color = txtColor.text;
                Navigator.pop(context);
              },
              child: Text("Edit")),
        ],
      ),
    );
  }
}
