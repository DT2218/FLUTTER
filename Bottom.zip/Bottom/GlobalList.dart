import 'package:bottom/Car.dart';

class GlobalList {
  static List<Car> lst = [];
  static int selectedindex = 0;
}
