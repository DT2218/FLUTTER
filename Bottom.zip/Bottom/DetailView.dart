import 'package:bottom/Edit.dart';
import 'package:bottom/GlobalList.dart';
import 'package:flutter/material.dart';

class DetailView extends StatefulWidget {
  const DetailView({super.key});

  @override
  State<DetailView> createState() => _DetailViewState();
}

class _DetailViewState extends State<DetailView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.cyan,
        title: Center(child: Text("Detail View")),
      ),
      body: Center(
        child: Column(
          children: [
            Text(
              GlobalList.lst[GlobalList.selectedindex].Name,
              style: TextStyle(fontSize: 30, color: Colors.red),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              GlobalList.lst[GlobalList.selectedindex].Price.toString(),
              style: TextStyle(fontSize: 30, color: Colors.red),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              GlobalList.lst[GlobalList.selectedindex].Color,
              style: TextStyle(fontSize: 30, color: Colors.red),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context) {
                          return Edit();
                        },
                      )).then(
                        (value) {
                          setState(() {});
                        },
                      );
                    },
                    child: Text("Edit")),
                ElevatedButton(
                    onPressed: () {
                      GlobalList.lst.removeAt(GlobalList.selectedindex);
                      Navigator.pop(context);
                    },
                    child: Text("Delete")),
              ],
            )
          ],
        ),
      ),
    );
  }
}
