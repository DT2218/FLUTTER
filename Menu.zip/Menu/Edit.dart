import 'package:flutter/material.dart';
import 'package:menu/GlobalList.dart';

class Edit extends StatefulWidget {
  const Edit({super.key});

  @override
  State<Edit> createState() => _EditState();
}

class _EditState extends State<Edit> {
  TextEditingController txtName = new TextEditingController();
  TextEditingController txtPrice = new TextEditingController();
  TextEditingController txtAuthor = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    txtName.text = GlobalList.lst[GlobalList.selectedindex].Name;
    txtPrice.text = GlobalList.lst[GlobalList.selectedindex].Price.toString();
    txtAuthor.text = GlobalList.lst[GlobalList.selectedindex].Author;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Center(child: Text("Edit Data")),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtName,
              decoration: InputDecoration(
                  label: Text("Enter Your Name"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtPrice,
              decoration: InputDecoration(
                  label: Text("Enter Your Price"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtAuthor,
              decoration: InputDecoration(
                  label: Text("Enter Your Author"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          ElevatedButton(
              onPressed: () {
                GlobalList.lst[GlobalList.selectedindex].Name = txtName.text;
                GlobalList.lst[GlobalList.selectedindex].Price =
                    int.parse(txtPrice.text);
                GlobalList.lst[GlobalList.selectedindex].Author =
                    txtAuthor.text;
                Navigator.pop(context);
              },
              child: Text("Edit")),
        ],
      ),
    );
  }
}
