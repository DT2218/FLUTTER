import 'package:menu/Book.dart';

class GlobalList {
  static List<Book> lst = [];
  static int selectedindex = 0;
}
