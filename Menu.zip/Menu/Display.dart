import 'package:flutter/material.dart';
import 'package:menu/DetailView.dart';
import 'package:menu/GlobalList.dart';

class Display extends StatefulWidget {
  const Display({super.key});

  @override
  State<Display> createState() => _DisplayState();
}

class _DisplayState extends State<Display> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: Center(child: Text("Display Data")),
        ),
        body: ListView.builder(
          itemCount: GlobalList.lst.length,
          itemBuilder: (context, index) {
            return Card(
              child: ListTile(
                onTap: () {
                  GlobalList.selectedindex = index;
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return DetailView();
                    },
                  )).then(
                    (value) {
                      setState(() {});
                    },
                  );
                },
                title: Text(GlobalList.lst[index].Name),
                subtitle: Text(GlobalList.lst[index].Price.toString()),
                leading: Icon(Icons.display_settings),
              ),
            );
          },
        ));
  }
}
