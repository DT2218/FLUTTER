import 'package:flutter/material.dart';
import 'package:menu/Book.dart';
import 'package:menu/Display.dart';
import 'package:menu/GlobalList.dart';

class Add extends StatefulWidget {
  const Add({super.key});

  @override
  State<Add> createState() => _AddState();
}

class _AddState extends State<Add> {
  TextEditingController txtName = new TextEditingController();
  TextEditingController txtPrice = new TextEditingController();
  TextEditingController txtAuthor = new TextEditingController();
  String View = "Total Data : ";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Center(child: Text("Add Data")),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtName,
              decoration: InputDecoration(
                  label: Text("Enter Your Name"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtPrice,
              decoration: InputDecoration(
                  label: Text("Enter Your Price"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtAuthor,
              decoration: InputDecoration(
                  label: Text("Enter Your Author"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          ElevatedButton(
              onPressed: () {
                Book obj = new Book();
                obj.Name = txtName.text;
                obj.Price = int.parse(txtPrice.text);
                obj.Author = txtAuthor.text;
                GlobalList.lst.add(obj);
                View = "Total Data : " + GlobalList.lst.length.toString();
                setState(() {});
              },
              child: Text("Add")),
          SizedBox(
            height: 20,
          ),
          Text(
            View,
            style: TextStyle(fontSize: 30, color: Colors.red),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) {
              return Display();
            },
          ));
        },
        child: Icon(Icons.navigate_next),
      ),
    );
  }
}
