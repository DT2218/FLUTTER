class Car {
  String Name = "";
  double Price = 0.0;
  String Color = "";
}
