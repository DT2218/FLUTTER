import 'package:flutter/material.dart';
import 'package:menu/Edit.dart';
import 'package:menu/GlobalList.dart';

class DetailView extends StatefulWidget {
  const DetailView({super.key});

  @override
  State<DetailView> createState() => _DetailViewState();
}

class _DetailViewState extends State<DetailView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow,
        title: Center(child: Text("Detail View")),
      ),
      body: Center(
        child: Column(
          children: [
            Text(
              GlobalList.lst[GlobalList.selectedindex].Name,
              style: TextStyle(fontSize: 30, color: Colors.red),
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              GlobalList.lst[GlobalList.selectedindex].Price.toString(),
              style: TextStyle(fontSize: 30, color: Colors.red),
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              GlobalList.lst[GlobalList.selectedindex].Author,
              style: TextStyle(fontSize: 30, color: Colors.red),
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context) {
                          return Edit();
                        },
                      )).then(
                        (value) {
                          setState(() {});
                        },
                      );
                    },
                    child: Text("Edit")),
                ElevatedButton(
                    onPressed: () {
                      GlobalList.lst.removeAt(GlobalList.selectedindex);
                      Navigator.pop(context);
                    },
                    child: Text("Delete")),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
