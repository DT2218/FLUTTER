import 'package:flutter/material.dart';
import 'package:menu/Add.dart';
import 'package:menu/Display.dart';
import 'package:menu/Search.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Dhruvil(),
  ));
}

class Dhruvil extends StatefulWidget {
  const Dhruvil({super.key});

  @override
  State<Dhruvil> createState() => _DhruvilState();
}

class _DhruvilState extends State<Dhruvil> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Center(child: Text("Menu Bar")),
      ),
      drawer: Drawer(
        child: Column(
          children: [
            UserAccountsDrawerHeader(
                currentAccountPicture: CircleAvatar(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.orange,
                  child: Text("D"),
                ),
                accountName: Text("Dhruvil Thakkar"),
                accountEmail: Text("Dhruvil@gmail.com")),
            Card(
              child: ListTile(
                title: Text("Add Data"),
                leading: Icon(Icons.add),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return Add();
                    },
                  ));
                },
              ),
            ),
            Card(
              child: ListTile(
                title: Text("Display Data"),
                leading: Icon(Icons.display_settings),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return Display();
                    },
                  ));
                },
              ),
            ),
            Card(
              child: ListTile(
                title: Text("Search Data"),
                leading: Icon(Icons.search),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return Search();
                    },
                  ));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
