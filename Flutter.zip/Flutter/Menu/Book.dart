class Book {
  String Name = "";
  int Price = 0;
  String Author = "";
}
