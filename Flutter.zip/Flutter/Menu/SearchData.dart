import 'package:flutter/material.dart';
import 'package:menu/Book.dart';
import 'package:menu/GlobalList.dart';

class SearchData extends StatefulWidget {
  String Data;

  SearchData(this.Data, {super.key});

  @override
  State<SearchData> createState() => _SearchDataState();
}

class _SearchDataState extends State<SearchData> {
  List<Book> lstlocal = [];

  @override
  Widget build(BuildContext context) {
    for (int cntr = 0; cntr < GlobalList.lst.length; cntr++) {
      if (GlobalList.lst[cntr].Price >= int.parse(widget.Data)) {
        lstlocal.add(GlobalList.lst[cntr]);
      }
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amberAccent,
        title: Center(child: Text("Search Data")),
      ),
      body: ListView.builder(
        itemCount: lstlocal.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(lstlocal[index].Name),
              subtitle: Text(lstlocal[index].Price.toString()),
            ),
          );
        },
      ),
    );
  }
}
