import 'package:flutter/material.dart';
import 'package:multiple/Detail.dart';
import 'package:multiple/GlobalList.dart';
import 'package:multiple/SearchData.dart';
import 'package:multiple/Student.dart';

void main() {
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: Dhruvil()));
}

class Dhruvil extends StatefulWidget {
  const Dhruvil({super.key});

  @override
  State<Dhruvil> createState() => _DhruvilState();
}

class _DhruvilState extends State<Dhruvil> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.orange,
            title: Center(child: Text("Multiple Tab")),
            bottom: TabBar(tabs: [
              Tab(
                child: Text("Add Data"),
                icon: Icon(Icons.add),
              ),
              Tab(
                child: Text("Display Data"),
                icon: Icon(Icons.display_settings),
              ),
              Tab(
                child: Text("Search Data"),
                icon: Icon(Icons.search),
              ),
            ]),
          ),
          body: TabBarView(children: [Add(), Display(), Search()]),
        ));
  }
}

class Add extends StatefulWidget {
  const Add({super.key});

  @override
  State<Add> createState() => _AddState();
}

class _AddState extends State<Add> {
  TextEditingController txtName = new TextEditingController();
  TextEditingController txtMarks = new TextEditingController();
  TextEditingController txtAddress = new TextEditingController();
  String View = "Total Data : ";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Center(child: Text("Add Data")),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtName,
              decoration: InputDecoration(
                  label: Text("Enter Your Name : "),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtMarks,
              decoration: InputDecoration(
                  label: Text("Enter Your Marks : "),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtAddress,
              decoration: InputDecoration(
                  label: Text("Enter Your Address : "),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ElevatedButton(
              onPressed: () {
                Student obj = new Student();
                obj.Name = txtName.text;
                obj.Marks = double.parse(txtMarks.text);
                obj.Address = txtAddress.text;
                GlobalList.lst.add(obj);
                View = "Total Data : " + GlobalList.lst.length.toString();
                setState(() {});
              },
              child: Text("Add")),
          SizedBox(
            height: 10,
          ),
          Text(
            View,
            style: TextStyle(fontSize: 30, color: Colors.green),
          )
        ],
      ),
    );
  }
}

class Display extends StatefulWidget {
  const Display({super.key});

  @override
  State<Display> createState() => _DisplayState();
}

class _DisplayState extends State<Display> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lime,
        title: Center(child: Text("Display Data")),
      ),
      body: ListView.builder(
        itemCount: GlobalList.lst.length,
        itemBuilder: (context, index) {
          return ListTile(
            tileColor: Colors.green,
            hoverColor: Colors.orange,
            title: Text(GlobalList.lst[index].Name),
            subtitle: Text(GlobalList.lst[index].Marks.toString()),
            leading: Icon(Icons.display_settings),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (context) {
                  GlobalList.selectedindex = index;
                  return Detail();
                },
              )).then(
                (value) {
                  setState(() {});
                },
              );
            },
          );
        },
      ),
    );
  }
}

class Search extends StatefulWidget {
  const Search({super.key});

  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {
  TextEditingController txtPrice = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: Center(child: Text("Search Data")),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtPrice,
              decoration: InputDecoration(
                  label: Text("Enter Search Price"),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30))),
            ),
          ),
          SizedBox(
            height: 30,
          ),
          ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return SearchData(txtPrice.text);
                  },
                ));
              },
              child: Icon(Icons.search))
        ],
      ),
    );
  }
}
