import 'package:flutter/material.dart';
import 'package:multiple/Edit.dart';
import 'package:multiple/GlobalList.dart';

class Detail extends StatefulWidget {
  const Detail({super.key});

  @override
  State<Detail> createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Center(child: Text("Detail View")),
      ),
      body: Column(
        children: [
          Text(
            GlobalList.lst[GlobalList.selectedindex].Name,
            style: TextStyle(color: Colors.red, fontSize: 30),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            GlobalList.lst[GlobalList.selectedindex].Marks.toString(),
            style: TextStyle(color: Colors.red, fontSize: 30),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            GlobalList.lst[GlobalList.selectedindex].Address,
            style: TextStyle(color: Colors.red, fontSize: 30),
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return Edit();
                      },
                    )).then(
                      (value) {
                        setState(() {});
                      },
                    );
                  },
                  child: Text("Edit")),
              ElevatedButton(
                  onPressed: () {
                    GlobalList.lst.removeAt(GlobalList.selectedindex);
                    Navigator.pop(context);
                  },
                  child: Text("Delete")),
            ],
          )
        ],
      ),
    );
  }
}
