import 'package:flutter/material.dart';
import 'package:multiple/GlobalList.dart';

class Edit extends StatefulWidget {
  const Edit({super.key});

  @override
  State<Edit> createState() => _EditState();
}

class _EditState extends State<Edit> {
  TextEditingController txtName = new TextEditingController();
  TextEditingController txtMarks = new TextEditingController();
  TextEditingController txtAddress = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    txtName.text = GlobalList.lst[GlobalList.selectedindex].Name;
    txtMarks.text = GlobalList.lst[GlobalList.selectedindex].Marks.toString();
    txtAddress.text = GlobalList.lst[GlobalList.selectedindex].Address;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink,
        title: Text("Edit Data"),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtName,
              decoration: InputDecoration(
                  label: Text("Enter Your Name : "),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtMarks,
              decoration: InputDecoration(
                  label: Text("Enter Your Marks : "),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: txtAddress,
              decoration: InputDecoration(
                  label: Text("Enter Your Address : "),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50))),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ElevatedButton(
              onPressed: () {
                GlobalList.lst[GlobalList.selectedindex].Name = txtName.text;
                GlobalList.lst[GlobalList.selectedindex].Marks =
                    double.parse(txtMarks.text);
                GlobalList.lst[GlobalList.selectedindex].Address =
                    txtAddress.text;
                Navigator.pop(context);
              },
              child: Text("Edit")),
        ],
      ),
    );
  }
}
