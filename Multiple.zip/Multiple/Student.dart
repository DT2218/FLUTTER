class Student{
  String Name = "";
  double Marks = 0.0;
  String Address = "";
}