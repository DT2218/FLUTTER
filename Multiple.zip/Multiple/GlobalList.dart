import 'package:multiple/Student.dart';

class GlobalList {
  static List<Student> lst = [];
  static int selectedindex = 0;
}
