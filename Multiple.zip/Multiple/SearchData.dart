import 'package:flutter/material.dart';
import 'package:multiple/GlobalList.dart';
import 'package:multiple/Student.dart';

class SearchData extends StatefulWidget {
  String Data;

  SearchData(this.Data, {super.key});

  @override
  State<SearchData> createState() => _SearchDataState();
}

class _SearchDataState extends State<SearchData> {
  List<Student> lstlocal = [];

  @override
  Widget build(BuildContext context) {
    for (int cntr = 0; cntr < GlobalList.lst.length; cntr++) {
      if (GlobalList.lst[cntr].Marks >= double.parse(widget.Data)) {
        lstlocal.add(GlobalList.lst[cntr]);
      }
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Center(child: Text("Search Data")),
      ),
      body: ListView.builder(
        itemCount: lstlocal.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              tileColor: Colors.red,
              title: Text(lstlocal[index].Name),
              subtitle: Text(lstlocal[index].Marks.toString()),
            ),
          );
        },
      ),
    );
  }
}
